# Pure CSS Card Open Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/electric90/pen/vYPzjOL](https://codepen.io/electric90/pen/vYPzjOL).

